//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MMFSparse.rc
//
#define IDC_STATIC              (-1)     // all static controls
#define IDD_MMFSPARSE                   1
#define IDC_CREATEMMF                   101
#define IDI_MMFSPARSE                   102
#define IDC_OFFSET                      103
#define IDC_WRITEBYTE                   105
#define IDC_READBYTE                    106
#define IDC_BYTE                        109
#define IDC_FILESTATUS                  1000
#define IDC_FREEALLOCATEDREGIONS        1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
